FixAnchor

FixAnchor, Unity UI elemanlarının anchor değerlerini otomatik olarak objenin kendi köşelerine sabitleyen küçük bir araçtır.

Kullanım:
1. Assets/FixAnchor/Editor klasörüne FixAnchorEditor.cs dosyasını ekle
2. Unity'de bir UI objesi seç
3. CTRL + Q tuşuna bas veya Tools > FixAnchor > Set Anchors To Corners menüsünü tıkla

Ekstra ayar veya dosya gerekmez.