using UnityEngine;

public class ToggleOption : MonoBehaviour
{
    public bool isCorrect;   // Inspector�dan ayarlayacaks�n
}
